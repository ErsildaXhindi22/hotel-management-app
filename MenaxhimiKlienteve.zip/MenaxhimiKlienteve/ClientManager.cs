using System;
using System.Collections.Generic;
using System.Linq;

public class ClientManager
{
    private List<Client> clients = new List<Client>();
    private int nextId = 1;

    public void AddClient(string firstName, string lastName, string phoneNumber, string email)
    {
        Client client = new Client
        {
            Id = nextId++,
            FirstName = firstName,
            LastName = lastName,
            PhoneNumber = phoneNumber,
            Email = email
        };
        clients.Add(client);
        Console.WriteLine("Klienti u shtua me sukses.");
    }

    public List<Client> SearchClients(string keyword)
    {
        return clients.Where(c =>
            c.FirstName.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            c.LastName.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            c.PhoneNumber.Contains(keyword)).ToList();
    }

    public bool UpdateClient(int id, string firstName, string lastName, string phoneNumber, string email)
    {
        var client = clients.FirstOrDefault(c => c.Id == id);
        if (client != null)
        {
            client.FirstName = firstName;
            client.LastName = lastName;
            client.PhoneNumber = phoneNumber;
            client.Email = email;
            return true;
        }
        return false;
    }

    public void DisplayAllClients()
    {
        foreach (var client in clients)
        {
            Console.WriteLine(client);
        }
    }
}