using System;

class Program
{
    static void Main()
    {
        ClientManager manager = new ClientManager();

        manager.AddClient("Arben", "Kola", "0691122334", "arben@example.com");
        manager.AddClient("Elira", "Dema", "0688877665", "elira@example.com");

        Console.WriteLine("\n--- Lista e klientëve ---");
        manager.DisplayAllClients();

        Console.WriteLine("\n--- Kërko klientë me fjalën 'Elira' ---");
        var results = manager.SearchClients("Elira");
        foreach (var c in results)
        {
            Console.WriteLine(c);
        }

        Console.WriteLine("\n--- Përditëso klient me ID 1 ---");
        if (manager.UpdateClient(1, "Arben", "Kola", "0699000000", "arbenkola@example.com"))
        {
            Console.WriteLine("Përditësimi u bë me sukses.");
        }

        Console.WriteLine("\n--- Lista pas përditësimit ---");
        manager.DisplayAllClients();
    }
}